/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"
#include "sdio.h"
#include "usart.h"
#include "gpio.h"
#include<stdio.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */

FATFS fs; //工作空间
FIL fil; // 文件项目
FIL fil0;
uint32_t byteswritten; // 写文件计数
uint32_t bytesread; // 读文件计数
uint8_t wtext[10]; // 写的内容
uint8_t rtext[1024]; // 读取的buff
char filename[] ="Hello.txt"; // 文件名
const uint8_t newline[]={0X0D,0X0A};//换行
uint8_t t=0;
short temperature;

void InitFatFas(void)
{
//-1- 挂载文件系统
	retSD = f_mount(&fs,"", 0);
	if(retSD)
	{
		HAL_UART_Transmit(&huart1, (uint8_t*)"er", 2, 0xffff);
		Error_Handler();
	}
	else
		HAL_UART_Transmit(&huart1, (uint8_t*)"sc", 2, 0xffff);
//-2-创建新的文件/
	HAL_Delay(800);
	retSD = f_open(&fil, "Hello.txt", FA_CREATE_ALWAYS); //打开文件，权限包括创建、写（如果没有该文件，会创建该文件）
	if(retSD==FR_OK)
		HAL_UART_Transmit(&huart1, (uint8_t*)"cr_sc", 5, 0xffff);
	else
		HAL_UART_Transmit(&huart1, (uint8_t*)"cr_sc", 5, 0xffff);
	f_close(&fil); //关闭该文件
	HAL_Delay(800);
}

//写入数据与读出，并通过printf打印、同时多行存入，避免数据覆盖。
//此处存入文件数据来自于DS18B20的采集。
void FatFsWrite(void)
{
	HAL_Delay(1);
//周期性读取数据并存储
	for(int i=0;i<10;i++)
	{
		/*temperature=DS18B20_Get_Temp();
		if(temperature<0)
		{
			temperature=-temperature; //转为正数
		}
		wtext[0]=' ';
		wtext[1]=(temperature/100)+48;
		wtext[2]=((temperature%100)/10)+48;
		wtext[3]='.';
		wtext[4]=((temperature%100)%10)+48;
		wtext[5]='C';*/
		wtext[0]='H';
		wtext[1]='e';
		wtext[2]='l';
		wtext[3]='l';
		wtext[4]='0';
		wtext[5]='!';
		//-2-创建新的文件并写入数据
		retSD = f_open(&fil,"Hello.txt",FA_WRITE); //打开文件，权限包括创建、写（如果没有该文件，会创建该文件）
		if(retSD==FR_OK) //返回值不为0（出现问题）
		{
			f_lseek(&fil,f_size(&fil));//将指针指向文件末尾
			retSD=f_write(&fil,wtext, sizeof(wtext),(void *)&byteswritten); //写数据
			if(retSD)
			{
				HAL_UART_Transmit(&huart1, (uint8_t*)"wr_er", 5, 0xffff);
			}
			else
			{
				HAL_UART_Transmit(&huart1, (uint8_t*)"wr_sc", 5, 0xffff);
				//printf("\r\nwrite Data : %s\r\n",wtext); //打印写入的内容
				//int arrLen = strlen(wtext);
				//HAL_UART_Transmit(&huart1, (uint8_t*) wtext, arrLen, 0xffff);
			}
			f_write(&fil, newline,2, (void *)&byteswritten); //换行
			f_close(&fil);
		}
		HAL_Delay(800);
	}

}

void FatFsRead(void)
{
    f_open(&fil,"Hello.txt",FA_READ);     //以只读方式打开文件
    char *temps;
    for(int i=0;i<10;i++)                  //由于知道文件里有232组数据所以设置232个循环
    {
        f_lseek(&fil,i*7);        //每次读取之前先移动读写指针达到读写不同数据的目的
        f_gets(temps,6,&fil0);    //读5个字节的数据
		int arrLen = strlen(temps);
		HAL_UART_Transmit(&huart1, (uint8_t*) temps, arrLen, 0xffff);
		HAL_UART_Transmit(&huart1, (uint8_t*)"Hello!", 6, 0xffff);
		HAL_Delay(800);

    }
}

int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_SDIO_SD_Init();
  MX_FATFS_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    /* USER CODE END WHILE */
	InitFatFas();
	FatFsWrite();
	FatFsRead();
    /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */




void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 72;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
