package edu.njust.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import edu.njust.dao.*;
import edu.njust.entity.*;


public class ItemService {
	public ArrayList findByPage(int n,int m) throws IOException
	{
		ItemDao itd=new ItemDao();
		ArrayList al=new ArrayList();
		List<Item> list=itd.findAll();
		for(int i=n;i<n+m;i++)
		{
			if(i>=list.size())
			{
				break;
			}
			else
			{
				al.add(list.get(i));
			}
		}
		return al;
	}
	public int getCount() throws IOException
	{
		ItemDao itd=new ItemDao();
		List<Item> list=itd.findAll();
		return list.size();
	}
	public Item findById(int itemid) throws IOException
	{
		ItemDao itd=new ItemDao();
		List<Item> list=itd.findItemById(itemid);
		return list.get(0);
	}
	public int buyItem(int itemid,int buyid) throws IOException
	{
		ItemDao itd=new ItemDao();
		Item item=new Item();
		item.setId(itemid);
		item.setBuyId(buyid);
		itd.updateBuyId(item);
		return 1;
	}
	public ArrayList findOrder(int userid) throws IOException
	{
		ItemDao itd=new ItemDao();
		ArrayList al=new ArrayList();
		List<Item> list=itd.findOrder(userid);
		for(int i=0;i<list.size();i++)
		{
			al.add(list.get(i));
		}
		return al;
	}
	public ArrayList findPost(int userid) throws IOException
	{
		ItemDao itd=new ItemDao();
		ArrayList al=new ArrayList();
		List<Item> list=itd.findPost(userid);
		for(int i=0;i<list.size();i++)
		{
			al.add(list.get(i));
		}
		return al;
	}
	public boolean addnewItem(Item newitem) throws IOException
	{
		ItemDao itd=new ItemDao();
		itd.addnewItem(newitem);
		return true;
	}
	public ArrayList findAll() throws IOException
	{
		ItemDao itd=new ItemDao();
		ArrayList al=new ArrayList();
		List<Item> list=itd.findAll();
		for(int i=0;i<list.size();i++)
		{
			al.add(list.get(i));
		}
		return al;
	}
	public boolean DelItem(int itemid) throws IOException
	{
		ItemDao itd=new ItemDao();
		itd.delItem(itemid);
		return true;
	}
}
