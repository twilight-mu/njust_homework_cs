package edu.njust.service;

import java.io.IOException;
import java.util.*;

import edu.njust.dao.*;
import edu.njust.entity.*;

public class MailService {
	public ArrayList findRecMail(int userid) throws IOException
	{
		MailDao md=new MailDao();
		ArrayList al=new ArrayList();
		List<Mail> list=md.findRecMail(userid);
		for(int i=0;i<list.size();i++)
		{
			al.add(list.get(i));
		}
		return al;
	}
	public ArrayList findSendMail(int userid) throws IOException
	{
		MailDao md=new MailDao();
		ArrayList al=new ArrayList();
		List<Mail> list=md.findSendMail(userid);
		for(int i=0;i<list.size();i++)
		{
			al.add(list.get(i));
		}
		return al;
	}
	public int haveread(int mailid) throws IOException
	{
		MailDao md=new MailDao();
		md.haveread(mailid);
		return 1;
	}
	public boolean postMail(Mail mail) throws IOException
	{
		MailDao md=new MailDao();
		md.addMail(mail);
		return true;
	}
	public ArrayList findAll() throws IOException
	{
		MailDao md=new MailDao();
		ArrayList al=new ArrayList();
		List<Mail> list=md.findAll();
		for(int i=0;i<list.size();i++)
		{
			al.add(list.get(i));
		}
		return al;
	}
	public boolean delMail(int mailid) throws IOException
	{
		MailDao md=new MailDao();
		md.delMail(mailid);
		return true;
	}
}
