package edu.njust.service;


import java.io.IOException;
import java.util.*;

import edu.njust.dao.*;
import edu.njust.entity.*;


public class UserService {
	public int checklogin(User user1) throws IOException
	{
		UserDao ud=new UserDao();
		List<User> list=ud.checkUser(user1.getName());
		if(list.size()==0)
		{
			return 1;//用户不存在
		}
		else
		{
			User user2=list.get(0);
			if(!user1.getPwd().equals(user2.getPwd()))
				return 2;//密码错误
			if(user1.getIsAdmin()!=user2.getIsAdmin())
				return 3;//用户类型错误
			if(user2.getIsLocked()==1)
				return 4;//用户被封
		}
		return 0;//登录成功
	}
	public int checksignup(String newname) throws IOException
	{
		UserDao ud=new UserDao();
		List<User> list=ud.findAlluser();
		for(int i=0;i<list.size();i++)
		{
			String uname=list.get(i).getName();
			if(uname.equals(newname))
			{
				return 1;//用户名重复
			}
		} 
		return 0;//注册信息无误
	}
	public int findIdByName(String username) throws IOException
	{
		UserDao ud=new UserDao();
		List<User> list=ud.checkUser(username);
		User user=list.get(0);
		return user.getId();
	}
	public ArrayList findAll() throws IOException
	{
		UserDao ud=new UserDao();
		List<User> list=ud.findAlluser();
		ArrayList al =new ArrayList();
		for(int i=0;i<list.size();i++)
		{
			al.add(list.get(i));
		}
		return al;
	}
	public int setLocked(int islocked,int id) throws IOException
	{
		UserDao ud=new UserDao();
		User user=new User();
		user.setId(id);
		user.setIsLocked(islocked);
		ud.updateLocked(user);
		return 1;
	}
	public boolean addnewUser(User newuser) throws IOException
	{
		UserDao ud=new UserDao();
		ud.addnewUser(newuser);
		return true;
	}
}