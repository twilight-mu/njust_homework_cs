package edu.njust.service;

import java.io.IOException;
import java.util.*;

import edu.njust.dao.*;
import edu.njust.entity.*;

public class ComplaintService {
	public ArrayList findAll() throws IOException
	{
		ComplaintDao cd=new ComplaintDao();
		List<Complaint> list=cd.findAll();
		ArrayList al=new ArrayList();
		for(int i=0;i<list.size();i++)
		{
			al.add(list.get(i));
		}
		return al;
	}
	public int updateReply(int compid,String reply) throws IOException
	{
		ComplaintDao cd=new ComplaintDao();
		Complaint comp=new Complaint();
		comp.setId(compid);
		comp.setReply(reply);
		cd.updateReply(comp);
		return 1;
	}	
	public ArrayList findBySendid(int userid) throws IOException
	{
		ComplaintDao cd=new ComplaintDao();
		List<Complaint> list=cd.findBySendid(userid);
		ArrayList al=new ArrayList();
		for(int i=0;i<list.size();i++)
		{
			al.add(list.get(i));
		}
		return al;
	}
	public boolean addComp(Complaint comp) throws IOException
	{
		ComplaintDao cd=new ComplaintDao();
		cd.addComp(comp);
		return true;
	}
}
