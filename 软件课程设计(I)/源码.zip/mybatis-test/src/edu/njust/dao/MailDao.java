package edu.njust.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import edu.njust.entity.*;

public class MailDao {
	public List<Mail> findRecMail(int receUserId) throws IOException
	{
		String resource = "mybatis-config.xml";           // 定位核心配置文件
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);    // 创建 SqlSessionFactory

        SqlSession sqlSession = sqlSessionFactory.openSession();    // 获取到 SqlSession

        // 调用 mapper 中的方法：命名空间 + id
        List<Mail> list = sqlSession.selectList("IMailDao.findRecMail",receUserId);
        return list;
	}
	
	public List<Mail> findSendMail(int sendUserId) throws IOException
	{
		String resource = "mybatis-config.xml";           // 定位核心配置文件
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);    // 创建 SqlSessionFactory

        SqlSession sqlSession = sqlSessionFactory.openSession();    // 获取到 SqlSession

        // 调用 mapper 中的方法：命名空间 + id
        List<Mail> list = sqlSession.selectList("IMailDao.findSendMail",sendUserId);
        return list;
	}
	
	public void haveread(int mailId) throws IOException
	{
		String resource = "mybatis-config.xml";           // 定位核心配置文件
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);    // 创建 SqlSessionFactory

        SqlSession sqlSession = sqlSessionFactory.openSession();    // 获取到 SqlSession

        sqlSession.update("IMailDao.haveread", mailId);
        sqlSession.commit(); 
	}
	
	public void addMail(Mail mail) throws IOException
	{
		String resource = "mybatis-config.xml";           // 定位核心配置文件
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);    // 创建 SqlSessionFactory

        SqlSession sqlSession = sqlSessionFactory.openSession();    // 获取到 SqlSession

        sqlSession.insert("IMailDao.addMail",mail);
        sqlSession.commit();
	}
	
	public List<Mail> findAll() throws IOException
	{
		String resource = "mybatis-config.xml";           // 定位核心配置文件
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);    // 创建 SqlSessionFactory

        SqlSession sqlSession = sqlSessionFactory.openSession();    // 获取到 SqlSession

        // 调用 mapper 中的方法：命名空间 + id
        List<Mail> list = sqlSession.selectList("IMailDao.findAll");
        return list;
	}
	
	public void delMail(int mailId) throws IOException
	{
		String resource = "mybatis-config.xml";           //定位核心配置文件
		 InputStream inputStream = Resources.getResourceAsStream(resource);
	     SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);    // 创建 SqlSessionFactory

	     SqlSession sqlSession = sqlSessionFactory.openSession();           // 获取到 SqlSession

        sqlSession.delete("IMailDao.delMail",mailId);
        sqlSession.commit(); 
	}
	
}
