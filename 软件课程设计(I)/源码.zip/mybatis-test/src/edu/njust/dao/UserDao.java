package edu.njust.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;



import edu.njust.entity.User;


public class UserDao {
	public List<User> checkUser(String username) throws IOException{

        String resource = "mybatis-config.xml";           // 定位核心配置文件
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);    // 创建 SqlSessionFactory

        SqlSession sqlSession = sqlSessionFactory.openSession();    // 获取到 SqlSession

        // 调用 mapper 中的方法：命名空间 + id
        List<User> list = sqlSession.selectList("IUserDao.checkUser",username);
        return list;
       
    }
	
	public List<User> findAlluser() throws IOException{
        String resource = "mybatis-config.xml";          
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);   
        SqlSession sqlSession = sqlSessionFactory.openSession();    
        List<User> list = sqlSession.selectList("IUserDao.findAlluser");
        for(int i=0;i<list.size();i++)
        {
        	User user=list.get(i);
        	System.out.println(user.getId()+" "+user.getName()+" "+user.getPwd()+" "+user.getIsAdmin()+" "+user.getIsLocked());
        }
        return list;    
    }
	
	public void updateLocked(User user) throws IOException{

        String resource = "mybatis-config.xml";           // 定位核心配置文件
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);    // 创建 SqlSessionFactory

        SqlSession sqlSession = sqlSessionFactory.openSession();    // 获取到 SqlSession

        sqlSession.update("IUserDao.updateLocked", user);
        sqlSession.commit(); 
       
    }
	
	public void addnewUser(User user) throws IOException{

        String resource = "mybatis-config.xml";           // 定位核心配置文件
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);    // 创建 SqlSessionFactory

        SqlSession sqlSession = sqlSessionFactory.openSession();    // 获取到 SqlSession

        sqlSession.insert("IUserDao.addnewUser", user);
        sqlSession.commit(); 
       
    }
	
}
