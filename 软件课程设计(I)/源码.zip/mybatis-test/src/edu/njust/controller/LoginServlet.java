package edu.njust.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.njust.entity.User;
import edu.njust.service.UserService;

public class LoginServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public LoginServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("gb2312");
		response.setContentType("text/html;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");

		HttpSession session = request.getSession();
		String checkcode=(String)session.getAttribute("CKECKCODE");
		String username=request.getParameter("uname");
		String pwd=request.getParameter("upwd");
		String code=request.getParameter("checkcode");
		String isadmin=request.getParameter("isAdmin");

		
		if(checkcode!= null && code.equals(checkcode))
		{
			User user=new User();
			user.setName(username);
			user.setPwd(pwd);
			if(isadmin.equals("1"))				
				user.setIsAdmin(1);
			else if(isadmin.equals("0"))
				user.setIsAdmin(0);
			UserService us=new UserService();
			int result=us.checklogin(user);//返回登录信息存入result
			if(result==0)
			{
				if(user.getIsAdmin()==0)
				{
					session.setAttribute("user_name",user.getName());
					session.setAttribute("user_id", us.findIdByName(user.getName()));
            		response.sendRedirect("main.jsp");
				}
				else
				{
					session.setAttribute("user_name",user.getName());
					session.setAttribute("user_id", us.findIdByName(user.getName()));
            		response.sendRedirect("mainforadmin.jsp");
				}
            }
			else
			{
            	request.setAttribute("error_code", new Integer(result));
            	request.getRequestDispatcher("loginFailure.jsp").forward(request,response);          	
            }
		}
		else
		{
			request.setAttribute("error_code", new Integer(5));
        	request.getRequestDispatcher("loginFailure.jsp").forward(request,response);
		}
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
