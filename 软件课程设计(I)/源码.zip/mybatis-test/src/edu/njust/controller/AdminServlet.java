package edu.njust.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.njust.entity.*;
import edu.njust.service.*;;

public class AdminServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public AdminServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");	
		HttpSession session = request.getSession(false);
		
		String op=request.getParameter("op");
		if(op.equals("query"))
		{
			ItemService is=new ItemService();
			ArrayList al=is.findAll();
			session.setAttribute("al", al);
			request.getRequestDispatcher("mainpageforadmin.jsp").forward(request,response);
		}
		else if(op.equals("details"))
		{
			int item_id=Integer.parseInt(request.getParameter("item"));
			ItemService is=new ItemService();
			Item item=is.findById(item_id);
			session.setAttribute("item_detail",item);
			request.getRequestDispatcher("detailsforadmin.jsp").forward(request,response);
		}
		else if(op.equals("backitem"))
		{
			int item_id=Integer.parseInt(request.getParameter("item"));
			ItemService is=new ItemService();
			boolean rs=is.DelItem(item_id);
			ArrayList al=is.findAll();
			session.setAttribute("al", al);
			request.getRequestDispatcher("mainpageforadmin.jsp").forward(request,response);
		}
		else if(op.equals("userlist"))
		{
			UserService us=new UserService();
			ArrayList al=us.findAll();
			session.setAttribute("al", al);
			request.getRequestDispatcher("userlist.jsp").forward(request,response);
		}
		else if(op.equals("lockuser"))
		{
			UserService us=new UserService();
			int user_id=Integer.parseInt(request.getParameter("user"));
			int rs=us.setLocked(1, user_id);
			ArrayList al=us.findAll();
			session.setAttribute("al", al);
			request.getRequestDispatcher("userlist.jsp").forward(request,response);
			
		}
		else if(op.equals("releaseuser"))
		{
			UserService us=new UserService();
			int user_id=Integer.parseInt(request.getParameter("user"));
			int rs=us.setLocked(0, user_id);
			ArrayList al=us.findAll();
			session.setAttribute("al", al);
			request.getRequestDispatcher("userlist.jsp").forward(request,response);
		}
		else if(op.equals("maillist"))
		{
			MailService ms=new MailService();
			ArrayList al=ms.findAll();
			session.setAttribute("al", al);
			request.getRequestDispatcher("maillist.jsp").forward(request,response);
		}
		else if(op.equals("backmail"))
		{
			int mail_id=Integer.parseInt(request.getParameter("mail"));
			MailService ms=new MailService();
			boolean rs=ms.delMail(mail_id);
			ArrayList al=ms.findAll();
			session.setAttribute("al", al);
			request.getRequestDispatcher("maillist.jsp").forward(request,response);
		}
		else if(op.equals("complist"))
		{
			ComplaintService cs=new ComplaintService();
			ArrayList al=cs.findAll();
			session.setAttribute("al", al);
			request.getRequestDispatcher("complaintlist.jsp").forward(request,response);
		}
		else if(op.equals("toreply"))
		{
			int comp_id=Integer.parseInt(request.getParameter("comp"));
			session.setAttribute("comp",comp_id);
			request.getRequestDispatcher("reply.jsp").forward(request,response);
		}
		else if(op.equals("reply"))
		{
			int comp_id=Integer.parseInt(session.getAttribute("comp").toString());
			ComplaintService cs=new ComplaintService();
			String content=request.getParameter("content");
			int rs=cs.updateReply(comp_id, content);
			ArrayList al=cs.findAll();
			session.setAttribute("al", al);
			request.getRequestDispatcher("complaintlist.jsp").forward(request,response);
		}
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
