package edu.njust.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import edu.njust.entity.*;
import edu.njust.service.*;;

public class ShopPageServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public ShopPageServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");	
		HttpSession session = request.getSession(false);
		
		String op=request.getParameter("op");
		if(op.equals("query"))
		{
			Page cp=(Page)session.getAttribute("page");
			String pg=request.getParameter("pg");
			ItemService is=new ItemService();
		
		
			if(is.getCount()%10==0)
			{
				cp.setMaxpage(is.getCount()/10);
			}
			else
			{
				cp.setMaxpage(is.getCount()/10+1);
			}
			int nowpage=cp.getNowpage();
			int maxpage=cp.getMaxpage();
			if(pg.equals("prev"))
			{
				cp.setNowpage(nowpage-1);
			}
			else if(pg.equals("next"))
			{
				cp.setNowpage(nowpage+1);
			}
			else if(pg.equals("first"))
			{
				cp.setNowpage(1);
			}
			else if(pg.equals("last"))
			{
				cp.setNowpage(maxpage);
			}
			nowpage=cp.getNowpage();
			ArrayList al=is.findByPage((nowpage-1)*10,10);
			session.setAttribute("al",al);
			session.setAttribute("page",cp);
			request.getRequestDispatcher("shopmain.jsp").forward(request,response);
		}
		else if(op.equals("details"))
		{
			int item_id=Integer.parseInt(request.getParameter("item"));
			ItemService is=new ItemService();
			Item item=is.findById(item_id);
			session.setAttribute("item_detail",item);
			request.getRequestDispatcher("details.jsp").forward(request,response);
		}
		else if(op.equals("buy"))
		{
			ItemService is=new ItemService();
			int item_id=Integer.parseInt(request.getParameter("item"));
			int buy_id=Integer.parseInt(session.getAttribute("user_id").toString());
			int rs=is.buyItem(item_id, buy_id);
			
			Page cp=(Page)session.getAttribute("page");
			String pg=request.getParameter("pg");
			
			if(is.getCount()%10==0)
			{
				cp.setMaxpage(is.getCount()/10);
			}
			else
			{
				cp.setMaxpage(is.getCount()/10+1);
			}
			int nowpage=cp.getNowpage();
			int maxpage=cp.getMaxpage();
			if(pg.equals("prev"))
			{
				cp.setNowpage(nowpage-1);
			}
			else if(pg.equals("next"))
			{
				cp.setNowpage(nowpage+1);
			}
			else if(pg.equals("first"))
			{
				cp.setNowpage(1);
			}
			else if(pg.equals("last"))
			{
				cp.setNowpage(maxpage);
			}
			nowpage=cp.getNowpage();
			ArrayList al=is.findByPage((nowpage-1)*10,10);
			session.setAttribute("al",al);
			session.setAttribute("page",cp);
			request.getRequestDispatcher("shopmain.jsp").forward(request,response);
		}
		else if(op.equals("myrecord"))
		{
			System.out.println("i am in myrecord");
			ItemService is=new ItemService();
			int userid=Integer.parseInt(session.getAttribute("user_id").toString());
			ArrayList al1=is.findOrder(userid);
			ArrayList al2=is.findPost(userid);
			session.setAttribute("orderlist", al1);
			session.setAttribute("postlist", al2);
			request.getRequestDispatcher("tradingrecord.jsp").forward(request,response);
		}
		
		
}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession(false);
		
		String itemname=null,itemtype=null,itemdep=null,itemtime=null,pname=null;
		FileItemFactory factory = new DiskFileItemFactory();
		 
        // 创建文件上传处理器
        ServletFileUpload upload = new ServletFileUpload(factory);

        // 开始解析请求信息
        List items = null;
        try {
            items = upload.parseRequest(request);
        }
        catch (FileUploadException e) {
            e.printStackTrace();
        }

        // 对所有请求信息进行判断
        Iterator iter = items.iterator();
        while (iter.hasNext()) {
            FileItem ite = (FileItem) iter.next();
            // 信息为普通的格式
            if (ite.isFormField()) {
                String fieldName = ite.getFieldName();
                String value = ite.getString("utf-8");
             
                if(fieldName.equals("itemname"))
                {
                	itemname=value;
                }
                else if(fieldName.equals("itemtype"))
                {
                	itemtype=value;
                }
                else if(fieldName.equals("itemdep"))
                {
                	itemdep=value;
                }
                else if(fieldName.equals("itemtime"))
                {
                	itemtime=value;
                }
                System.out.println(fieldName+" "+value);
                request.setAttribute(fieldName, value);
            }
            // 信息为文件格式
            else {
                String fileName = ite.getName();
                
                pname=fileName;
                
                System.out.println(fileName);
                int index = fileName.lastIndexOf("\\");
                fileName = fileName.substring(index + 1);
                request.setAttribute("realFileName", fileName);

                String basePath = request.getRealPath("/image");
                File file = new File(basePath, fileName);
                try {
                    ite.write(file);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        ItemService is=new ItemService();
		Item item=new Item();
		item.setName(itemname);
		if(itemtype.equals("1"))
		{
			item.setType("学习用品");
		}
		else if(itemtype.equals("2"))
		{
			item.setType("电子产品");
		}
		else if(itemtype.equals("3"))
		{
			item.setType("日用杂货");
		}
		else if(itemtype.equals("4"))
		{
			item.setType("书籍");
		}
		else if(itemtype.equals("5"))
		{
			item.setType("其他");
		}
		
		item.setdep(itemdep);
		
		if(pname==null||pname.equals(""))
		{
			item.setPicture("error.png");
		}
		else
		{
			item.setPicture(pname);
		}
		java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		try 
		{
			item.setPostTime(formatter.parse(itemtime));
		} 
		catch (ParseException e) 
		{
			e.printStackTrace();
		}
		item.setPostId(Integer.parseInt(session.getAttribute("user_id").toString()));
		item.setBuyId(-1);
		
		System.out.println(item.getName()+item.getType()+item.getdep()+item.getPostTime());
		boolean rs=is.addnewItem(item);
		
		Page cp=(Page)session.getAttribute("page");

		String pg="none";
	
	
		if(is.getCount()%10==0)
		{
			cp.setMaxpage(is.getCount()/10);
		}
		else
		{
			cp.setMaxpage(is.getCount()/10+1);
		}
		int nowpage=cp.getNowpage();
		int maxpage=cp.getMaxpage();
		if(pg.equals("prev"))
		{
			cp.setNowpage(nowpage-1);
		}
		else if(pg.equals("next"))
		{
			cp.setNowpage(nowpage+1);
		}
		else if(pg.equals("first"))
		{
			cp.setNowpage(1);
		}
		else if(pg.equals("last"))
		{
			cp.setNowpage(maxpage);
		}
		nowpage=cp.getNowpage();
		ArrayList al=is.findByPage((nowpage-1)*10,10);
		session.setAttribute("al",al);
		session.setAttribute("page",cp);
		request.getRequestDispatcher("shopmain.jsp").forward(request,response);
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
