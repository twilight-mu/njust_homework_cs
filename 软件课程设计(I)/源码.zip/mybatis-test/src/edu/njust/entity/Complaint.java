package edu.njust.entity;

import java.util.Date;

public class Complaint {
	private int id;
	private int sendid;
	private String content;
	private Date posttime;
	private String reply;
	
	public int getId()
	{
		return this.id;
	}
	public void setId(int id)
	{
		this.id=id;
	}
	
	public int getSendid()
	{
		return this.sendid;
	}
	public void setSendid(int sendid)
	{
		this.sendid=sendid;
	}
	
	public String getContent()
	{
		return this.content;
	}
	public void setContent(String content)
	{
		this.content=content;
	}
	
	public Date getPosttime()
	{
		return this.posttime;
	}
	public void setPosttime(Date posttime)
	{
		this.posttime=posttime;
	}
	
	public String getReply()
	{
		return this.reply;
	}
	public void setReply(String reply)
	{
		this.reply=reply;
	}
	
}
