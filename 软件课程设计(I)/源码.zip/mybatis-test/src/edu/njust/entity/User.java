package edu.njust.entity;

public class User {
	private int userId;
	private String userName;
	private String password;
	private int isAdmin;
	private int isLocked;
	public User(){
		
	}
	public User(int userId,String userName,String password,int isAdmin,int isLocked){
		this.userId=userId;
		this.userName=userName;
		this.password=password;
		this.isAdmin=isAdmin;
		this.isLocked=isLocked;
	}
	
	public int getId()
	{
		return this.userId;
	}
	public void setId(int userId)
	{
		this.userId=userId;
	}
	
	public String getName()
	{
		return this.userName;
	}
	public void setName(String userName)
	{
		this.userName=userName;
	}
	
	public String getPwd()
	{
		return this.password;
	}
	public void setPwd(String password)
	{
		this.password=password;
	}
	
	public int getIsAdmin()
	{
		return this.isAdmin;
	}
	public void setIsAdmin(int isAdmin)
	{
		this.isAdmin=isAdmin;
	}
	
	public int getIsLocked()
	{
		return this.isLocked;
	}
	public void setIsLocked(int isLocked)
	{
		this.isLocked=isLocked;
	}
}
