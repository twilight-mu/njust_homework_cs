package edu.njust.entity;

import java.util.Date;

import edu.njust.utils.CalendarUtil;

public class Item {
	private int itemId;
	private String itemName;
	private String itemType;
	private String description;
	private Date postTime;
	private int postUserId;
	private int BuyUserId;
	private String picture;
	
	public int getId()
	{
		return this.itemId;
	}
	public void setId(int itemId)
	{
		this.itemId=itemId;
	}
	
	public String getName()
	{
		return this.itemName;
	}
	public void setName(String itemName)
	{
		this.itemName=itemName;
	}
	
	public String getType()
	{
		return this.itemType;
	}
	public void setType(String itemType)
	{
		this.itemType=itemType;
	}
	
	public String getdep()
	{
		return this.description;
	}
	public void setdep(String description)
	{
		this.description=description;
	}
	
	public Date getPostTime()
	{
		return this.postTime;
	}
	public void setPostTime(Date postTime)
	{
		this.postTime=postTime;
	}
	
	public int getPostId()
	{
		return this.postUserId;
	}
	public void setPostId(int postUserId)
	{
		this.postUserId=postUserId;
	}
	
	public int getBuyId()
	{
		return this.BuyUserId;
	}
	public void setBuyId(int BuyUserId)
	{
		this.BuyUserId=BuyUserId;
	}
	
	public String getPicture()
	{
		return this.picture;
	}
	public void setPicture(String picture)
	{
		this.picture=picture;
	}
	
	public String getFormattedDate(){
		String dateStr = CalendarUtil.dateFormat(this.postTime);
		//System.out.println(dateStr);
		return dateStr;
	}
}
