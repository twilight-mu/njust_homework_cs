package edu.njust.entity;

import java.util.Date;

public class Mail {
	private int mailId;
	private int sendUserId;
	private int receUserId;
	private String content;
	private Date sendTime;
	private int isRead;
	
	public int getId()
	{
		return this.mailId;
	}
	public void setId(int mailId)
	{
		this.mailId=mailId;
	}
	
	public int getsendId()
	{
		return this.sendUserId;
	}
	public void setsendId(int sendUserId)
	{
		this.sendUserId=sendUserId;
	}
	
	public int getreceId()
	{
		return this.receUserId;
	}
	public void setreceId(int receUserId)
	{
		this.receUserId=receUserId;
	}
	
	public String getcontent()
	{
		return this.content;
	}
	public void setcontent(String content)
	{
		this.content=content;
	}
	
	public Date getTime()
	{
		return this.sendTime;
	}
	public void setTime(Date sendTime)
	{
		this.sendTime=sendTime;
	}
	
	public int getIsRead()
	{
		return this.isRead;
	}
	public void setIsRead(int isRead)
	{
		this.isRead=isRead;
	}
}
